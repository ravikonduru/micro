package org.customer.service.intercomm;

public class Hello {
	public Hello(String value){
		System.out.println("###############Callback Called..." + value);
	}
}
