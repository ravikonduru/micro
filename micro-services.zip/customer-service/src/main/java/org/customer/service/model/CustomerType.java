package org.customer.service.model;

public enum CustomerType {
	INDIVIDUAL, COMPANY;
}
